import time
import os

print("SELAMAT DATANG DI TOOLS IDENTITAS")
print("tols ini memungkinkan anda membuat data anda di terminal")
print("tunggu 5dtk")
time.sleep(5)
os.system("clear")

# ===== INPUT NAMA LENGKAP =====
nama = input("Nama Lengkap: ")
time.sleep(0.1)
os.system("clear")
print(f"halo {nama}")
time.sleep(2)
os.system("clear")

# ===== INPUT UMUR =====
print(f"Nama Lengkap = {nama}")
umur = input("Umur: ")
os.system("clear")
print(f"ohh oke umur kamu {umur}")
time.sleep(2)
os.system("clear")

# ===== INPUT GENDER =====
print(f"Nama Lengkap = {nama}")
print(f"Umur         = {umur}")
gender = input("Gender: ")
os.system("clear")
print(f"oke gender kamu {gender}")
time.sleep(2)
os.system("clear")

# ===== INPUT ALAMAT =====
print(f"Nama Lengkap = {nama}")
print(f"Umur         = {umur}")
print(f"Gender       = {gender}")
alamat = input("Alamat: ")
os.system("clear")
print(f"oke alamat kamu {alamat}")
time.sleep(2)
os.system("clear")

# ===== INPUT STATUS =====
print(f"Nama Lengkap = {nama}")
print(f"Umur         = {umur}")
print(f"Gender       = {gender}")
print(f"Alamat       = {alamat}")
status = input("Status: ")
os.system("clear")
print(f"oke status kamu {status}")
time.sleep(2)
os.system("clear")

# ===== INPUT AGAMA =====
print(f"Nama Lengkap = {nama}")
print(f"Umur         = {umur}")
print(f"Gender       = {gender}")
print(f"Alamat       = {alamat}")
print(f"Status       = {status}")
agama = input("Agama: ")
os.system("clear")
print(f"oke agama kamu {agama}")
time.sleep(2)
os.system("clear")

# ===== TAMPILKAN SEMUA DATA =====
print(f"Nama Lengkap = {nama}")
print(f"Umur         = {umur}")
print(f"Gender       = {gender}")
print(f"Alamat       = {alamat}")
print(f"Status       = {status}")
print(f"Agama        = {agama}")
print()

# ===== SIMPAN KE FILE TXT =====
simpan = input("Simpan data ke file? (y/n): ")

if simpan.lower() == "y":
    with open("data_identitas.txt", "a") as file:
        file.write("=" * 30 + "\n")
        file.write(f"Nama Lengkap = {nama}\n")
        file.write(f"Umur         = {umur}\n")
        file.write(f"Gender       = {gender}\n")
        file.write(f"Alamat       = {alamat}\n")
        file.write(f"Status       = {status}\n")
        file.write(f"Agama        = {agama}\n")
        file.write("=" * 30 + "\n\n")
    print("Data berhasil disimpan ke 'data_identitas.txt'")
else:
    print("Data tidak disimpan")
